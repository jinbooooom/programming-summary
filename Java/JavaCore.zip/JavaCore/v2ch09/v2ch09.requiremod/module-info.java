@SuppressWarnings("module")
module v2ch09.requiremod
{
   requires java.desktop;
}
