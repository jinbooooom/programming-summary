@SuppressWarnings("module")
module v2ch09.useservice 
{
   requires com.horstmann.greetsvc;
   uses com.horstmann.greetsvc.GreeterService;
}
